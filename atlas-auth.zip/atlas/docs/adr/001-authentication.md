# ADR-001: Authentication Strategy

**Status:** Accepted  
**Date:** Phase 0

---

## Context

Atlas needs email + password login and Google OAuth, with sessions that work across the Next.js App Router (server components, server actions, middleware).

## Decision

**Auth.js v5** with:
- **JWT session strategy** — one strategy that works for both Credentials and OAuth providers without per-provider logic
- **DrizzleAdapter** — persists users and linked OAuth accounts; sessions stay in the JWT cookie
- **bcryptjs work factor 12** — secure default, measurable on every registration
- **Server Actions** for form submission — no client-side fetch, progressively enhanced

## Consequences

**Good:**
- Sessions are stateless (no DB hit per request in middleware)
- Single `auth()` call works identically in Server Components, layouts, API routes, and server actions
- DrizzleAdapter handles OAuth account linking automatically
- Defense-in-depth: middleware redirects at edge + layout redirects server-side

**Trade-offs:**
- Sessions can't be remotely invalidated without a token blocklist (acceptable for v1 single-user)
- bcrypt must run in Node.js runtime (not Cloudflare Workers edge) — fine since credentials POST goes through `/api/auth/callback/credentials`

## Alternatives Considered

- **Lucia** — more control but more boilerplate; revisit if Auth.js becomes a constraint
- **Clerk** — fastest to ship but adds SaaS dependency and no data ownership; against Atlas principle §1.5
- **Database sessions** — enables invalidation but adds a DB read to every middleware check
