import { neon } from "@neondatabase/serverless"
import { drizzle } from "drizzle-orm/neon-http"
import * as schema from "./schema"

if (!process.env.DATABASE_URL) {
  throw new Error(
    "Missing DATABASE_URL. Add it to .env.local or your deployment environment."
  )
}

const sql = neon(process.env.DATABASE_URL)

export const db = drizzle(sql, {
  schema,
  // Log queries only in development — never in production
  logger: process.env.NODE_ENV === "development",
})
