import {
  integer,
  pgTable,
  primaryKey,
  text,
  timestamp,
} from "drizzle-orm/pg-core"
import type { AdapterAccountType } from "next-auth/adapters"

// ---------------------------------------------------------------------------
// users
// Auth.js adapter expects these property names: id, name, email, emailVerified, image
// We add Atlas-specific fields: passwordHash, workspaceId, createdAt, updatedAt
// ---------------------------------------------------------------------------
export const users = pgTable("users", {
  id: text("id")
    .primaryKey()
    .$defaultFn(() => crypto.randomUUID()),
  name: text("name"),
  email: text("email").unique().notNull(),
  // property: emailVerified  → column: email_verified
  emailVerified: timestamp("email_verified", { mode: "date" }),
  image: text("image"),

  // Atlas-specific — not touched by the adapter
  passwordHash: text("password_hash"),
  workspaceId: text("workspace_id"), // Multi-tenant ready from day 1 (§3.3)
  createdAt: timestamp("created_at", { mode: "date" }).defaultNow().notNull(),
  updatedAt: timestamp("updated_at", { mode: "date" }).defaultNow().notNull(),
})

// ---------------------------------------------------------------------------
// accounts
// Stores linked OAuth providers. The adapter accesses these by JS property name,
// so camelCase properties are required even when the DB column is snake_case.
// The snake_case fields (refresh_token, access_token, etc.) are Auth.js's own
// naming — keep them as-is.
// ---------------------------------------------------------------------------
export const accounts = pgTable(
  "accounts",
  {
    // property: userId → column: user_id
    userId: text("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    type: text("type").$type<AdapterAccountType>().notNull(),
    provider: text("provider").notNull(),
    // property: providerAccountId → column: provider_account_id
    providerAccountId: text("provider_account_id").notNull(),

    // Auth.js uses snake_case for these token fields — match exactly
    refresh_token: text("refresh_token"),
    access_token: text("access_token"),
    expires_at: integer("expires_at"),
    token_type: text("token_type"),
    scope: text("scope"),
    id_token: text("id_token"),
    session_state: text("session_state"),
  },
  (account) => ({
    compoundKey: primaryKey({
      columns: [account.provider, account.providerAccountId],
    }),
  })
)

// ---------------------------------------------------------------------------
// sessions
// Used when session strategy is "database". We default to "jwt" but keep the
// table so switching strategies later costs nothing.
// property: sessionToken → column: session_token
// ---------------------------------------------------------------------------
export const sessions = pgTable("sessions", {
  sessionToken: text("session_token").primaryKey(),
  userId: text("user_id")
    .notNull()
    .references(() => users.id, { onDelete: "cascade" }),
  expires: timestamp("expires", { mode: "date" }).notNull(),
})

// ---------------------------------------------------------------------------
// verificationTokens
// Used for email magic links and future password-reset flows.
// ---------------------------------------------------------------------------
export const verificationTokens = pgTable(
  "verification_tokens",
  {
    identifier: text("identifier").notNull(),
    token: text("token").notNull(),
    expires: timestamp("expires", { mode: "date" }).notNull(),
  },
  (vt) => ({
    compoundKey: primaryKey({ columns: [vt.identifier, vt.token] }),
  })
)

// ---------------------------------------------------------------------------
// Inferred types — used throughout the app for type safety
// ---------------------------------------------------------------------------
export type User = typeof users.$inferSelect
export type NewUser = typeof users.$inferInsert
export type Account = typeof accounts.$inferSelect
export type Session = typeof sessions.$inferSelect
