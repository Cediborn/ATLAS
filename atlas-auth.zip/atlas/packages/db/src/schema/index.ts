// Re-export all domain schemas.
// New schemas (tasks, notes, habits, etc.) are added here as phases progress.
export * from "./auth"
