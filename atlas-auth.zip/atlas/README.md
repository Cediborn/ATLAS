# Atlas

A personal operating system. Tasks, notes, calendar, habits, learning, and finance — unified, keyboard-first, AI-ambient.

> **Status:** Phase 0 — Authentication complete. App shell coming in Phase 1.

---

## Stack

| Layer | Choice |
|---|---|
| Framework | Next.js 14 (App Router) |
| Language | TypeScript (strict) |
| Auth | Auth.js v5 — Google OAuth + email/password |
| Database | PostgreSQL via Neon + Drizzle ORM |
| Styling | Tailwind CSS |
| Monorepo | Turborepo + pnpm workspaces |
| Hosting | Vercel (app) + Neon (DB) |

---

## Local setup

### 1. Prerequisites
```bash
node --version   # needs ≥ 20
pnpm --version   # needs ≥ 9  →  npm i -g pnpm
```

### 2. Clone and install
```bash
git clone https://github.com/YOUR_USERNAME/atlas.git
cd atlas
pnpm install
```

### 3. Environment variables
```bash
cp .env.example .env.local
```

Fill in `.env.local`:

| Variable | Where to get it |
|---|---|
| `DATABASE_URL` | [neon.tech](https://neon.tech) → your project → Connection string |
| `AUTH_SECRET` | Run: `openssl rand -base64 32` |
| `AUTH_URL` | `http://localhost:3000` |
| `AUTH_GOOGLE_ID` | [Google Cloud Console](https://console.cloud.google.com) → APIs & Services → Credentials |
| `AUTH_GOOGLE_SECRET` | Same as above |

**Google OAuth redirect URI** (add this in Google Console):
```
http://localhost:3000/api/auth/callback/google
```

### 4. Push database schema
```bash
pnpm db:push
```

### 5. Run
```bash
pnpm dev
# → http://localhost:3000  (redirects to /login)
```

---

## Project structure

```
atlas/
├── apps/
│   └── web/                        # Next.js app
│       ├── app/
│       │   ├── (auth)/             # Public: /login, /register, /auth/error
│       │   ├── (protected)/        # Private: /dashboard (and all future pages)
│       │   └── api/auth/           # Auth.js route handler
│       ├── components/auth/        # AuthCard, LoginForm, RegisterForm, GoogleButton
│       ├── lib/
│       │   ├── actions/auth.ts     # Server actions (login, register)
│       │   ├── auth/               # Helpers: getCurrentUser, requireAuth
│       │   └── validators/auth.ts  # Zod schemas
│       ├── auth.ts                 # NextAuth v5 config (single source of truth)
│       └── middleware.ts           # Edge route protection
├── packages/
│   └── db/                         # @atlas/db — Drizzle schema + client
│       └── src/
│           ├── schema/auth.ts      # users, accounts, sessions, verification_tokens
│           └── index.ts
└── docs/
    └── adr/                        # Architecture decision records
```

---

## Auth flows

| Flow | How it works |
|---|---|
| Email/password register | `RegisterForm` → `registerAction` server action → bcrypt hash → insert user → auto sign-in |
| Email/password login | `LoginForm` → `loginAction` server action → `signIn("credentials")` → JWT |
| Google OAuth | `GoogleButton` → inline server action → `signIn("google")` → adapter creates/links user |
| Route protection | Middleware (edge) + protected layout (server component, defence-in-depth) |
| Sign out | Inline server action → `signOut({ redirectTo: "/login" })` |

---

## Roadmap

| Phase | Goal |
|---|---|
| ✅ 0 | Foundation — architecture, design system tokens, auth |
| 1 | App shell — layout, sidebar, command palette (⌘K) |
| 2 | Tasks + Notes — first two pillars, cross-linking |
| 3 | Calendar + Habits |
| 4 | Learning + Finance |
| 5 | AI layer — quick-capture parsing, summaries |
| 6 | Analytics |
| 7 | Local-first sync + Desktop (Tauri) |

---

## Deploy to Vercel

1. Push to GitHub
2. Import repo at [vercel.com](https://vercel.com)
3. Add the same env variables from `.env.local` in Vercel's dashboard
4. Update `AUTH_URL` to your production domain
5. Add the production redirect URI in Google Console:
   ```
   https://yourdomain.com/api/auth/callback/google
   ```
6. Deploy — Vercel auto-detects Next.js.
