import type { Config } from "tailwindcss"

const config: Config = {
  darkMode: "class",
  content: [
    "./app/**/*.{ts,tsx}",
    "./components/**/*.{ts,tsx}",
    "./lib/**/*.{ts,tsx}",
  ],
  theme: {
    extend: {
      fontFamily: {
        sans: ["Inter", "system-ui", "sans-serif"],
        mono: ["JetBrains Mono", "ui-monospace", "monospace"],
      },
      fontSize: {
        // Atlas type scale: 12/14/16(base)/18/20/24/32/40
        xs: ["0.75rem", { lineHeight: "1.5" }],
        sm: ["0.875rem", { lineHeight: "1.5" }],
        base: ["1rem", { lineHeight: "1.5" }],
        lg: ["1.125rem", { lineHeight: "1.5" }],
        xl: ["1.25rem", { lineHeight: "1.2" }],
        "2xl": ["1.5rem", { lineHeight: "1.2" }],
        "3xl": ["2rem", { lineHeight: "1.2" }],
        "4xl": ["2.5rem", { lineHeight: "1.1" }],
      },
      borderRadius: {
        // Atlas radii: 6px inputs/buttons, 12px cards, 20px modals
        DEFAULT: "6px",
        md: "6px",
        lg: "12px",
        xl: "20px",
      },
      spacing: {
        // Atlas 4px base unit scale
        1: "0.25rem",
        2: "0.5rem",
        3: "0.75rem",
        4: "1rem",
        6: "1.5rem",
        8: "2rem",
        12: "3rem",
        16: "4rem",
        24: "6rem",
      },
      transitionDuration: {
        // Atlas motion: 120ms micro, 200ms standard, 320ms panel
        micro: "120ms",
        standard: "200ms",
        panel: "320ms",
      },
      transitionTimingFunction: {
        // Atlas easing
        atlas: "cubic-bezier(0.16, 1, 0.3, 1)",
      },
    },
  },
  plugins: [],
}

export default config
