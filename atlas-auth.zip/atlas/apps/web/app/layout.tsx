import type { Metadata, Viewport } from "next"
import { Inter, JetBrains_Mono } from "next/font/google"
import "./globals.css"

const inter = Inter({
  subsets: ["latin"],
  display: "swap",
  variable: "--font-inter",
})

const jetbrainsMono = JetBrains_Mono({
  subsets: ["latin"],
  display: "swap",
  variable: "--font-mono",
})

export const metadata: Metadata = {
  title: {
    template: "%s — Atlas",
    default: "Atlas",
  },
  description: "Your personal operating system.",
}

export const viewport: Viewport = {
  themeColor: [
    { media: "(prefers-color-scheme: light)", color: "#fafafa" },
    { media: "(prefers-color-scheme: dark)", color: "#09090b" },
  ],
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html
      lang="en"
      // "class" strategy — toggled by user preference (Phase 1)
      // Defaults to system preference via CSS media query fallback
      suppressHydrationWarning
    >
      <body
        className={`
          ${inter.variable} ${jetbrainsMono.variable}
          font-sans antialiased
          bg-white text-neutral-900
          dark:bg-neutral-950 dark:text-neutral-50
        `}
      >
        {children}
      </body>
    </html>
  )
}
