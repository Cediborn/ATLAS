import { auth, signOut } from "@/auth"
import type { Metadata } from "next"

export const metadata: Metadata = { title: "Dashboard — Atlas" }

/**
 * Placeholder dashboard — will be replaced by the full app shell in Phase 1.
 * Exists now to prove the auth flow works end-to-end.
 */
export default async function DashboardPage() {
  const session = await auth()
  const user = session!.user // Layout already guarantees a session exists

  return (
    <main className="flex min-h-screen flex-col items-center justify-center gap-6 p-8">
      {/* Minimal confirmation UI */}
      <div className="w-full max-w-sm space-y-4 rounded-lg border border-neutral-200 bg-white p-6 dark:border-neutral-800 dark:bg-neutral-900">
        <div>
          <p className="text-xs font-medium uppercase tracking-widest text-neutral-400">
            Signed in as
          </p>
          <p className="mt-1 font-medium text-neutral-900 dark:text-neutral-50">
            {user.name ?? "—"}
          </p>
          <p className="text-sm text-neutral-500">{user.email}</p>
        </div>

        <div className="border-t border-neutral-100 pt-4 dark:border-neutral-800">
          <p className="text-xs text-neutral-400">
            Atlas Phase 0 — authentication verified ✓
          </p>
          <p className="mt-0.5 text-xs text-neutral-400">
            User ID: <code className="font-mono">{user.id}</code>
          </p>
        </div>

        {/* Sign-out via server action */}
        <form
          action={async () => {
            "use server"
            await signOut({ redirectTo: "/login" })
          }}
        >
          <button
            type="submit"
            className="
              w-full rounded-md border border-neutral-200 bg-white
              px-4 py-2 text-sm text-neutral-700
              transition-colors hover:bg-neutral-50
              dark:border-neutral-700 dark:bg-transparent
              dark:text-neutral-300 dark:hover:bg-neutral-800
            "
          >
            Sign out
          </button>
        </form>
      </div>

      <p className="max-w-sm text-center text-sm text-neutral-400">
        The app shell, sidebar, and command palette arrive in Phase 1.
      </p>
    </main>
  )
}
