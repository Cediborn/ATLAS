import { redirect } from "next/navigation"
import { auth } from "@/auth"

/**
 * Protected layout — wraps all routes that require authentication.
 * The middleware handles the primary redirect at the edge; this is the
 * server-component fallback (defense-in-depth).
 *
 * Future home of the app shell: sidebar, command palette, top nav.
 */
export default async function ProtectedLayout({
  children,
}: {
  children: React.ReactNode
}) {
  const session = await auth()

  if (!session?.user) {
    redirect("/login")
  }

  return (
    // TODO (Phase 1): Replace with AppShell component (sidebar + command palette)
    <div className="min-h-screen bg-white dark:bg-neutral-950">{children}</div>
  )
}
