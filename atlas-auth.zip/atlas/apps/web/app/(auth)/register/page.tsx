import type { Metadata } from "next"
import Link from "next/link"
import { AuthCard } from "@/components/auth/auth-card"
import { RegisterForm } from "@/components/auth/register-form"
import { AuthDivider } from "@/components/auth/auth-divider"
import { GoogleButton } from "@/components/auth/google-button"

export const metadata: Metadata = {
  title: "Create account",
  description: "Create your Atlas account.",
}

export default function RegisterPage() {
  return (
    <AuthCard
      title="Create your account"
      description="Start building your personal operating system."
      footer={
        <>
          Already have an account?{" "}
          <Link
            href="/login"
            className="font-medium text-neutral-900 underline-offset-2 hover:underline dark:text-neutral-50"
          >
            Sign in
          </Link>
        </>
      }
    >
      <RegisterForm />
      <AuthDivider />
      <GoogleButton callbackUrl="/dashboard" />
    </AuthCard>
  )
}
