import type { Metadata } from "next"
import Link from "next/link"
import { AuthCard } from "@/components/auth/auth-card"

export const metadata: Metadata = {
  title: "Authentication error",
}

// Auth.js passes the error code as a ?error= query parameter
const ERROR_MESSAGES: Record<string, { heading: string; message: string }> = {
  Configuration: {
    heading: "Server configuration error",
    message:
      "There is a problem with the server's authentication configuration. Please contact support.",
  },
  AccessDenied: {
    heading: "Access denied",
    message:
      "You do not have permission to sign in. If you believe this is a mistake, please contact support.",
  },
  Verification: {
    heading: "Link expired",
    message:
      "The sign-in link has expired or has already been used. Please request a new one.",
  },
  OAuthAccountNotLinked: {
    heading: "Email already in use",
    message:
      "An account with this email address already exists using a different sign-in method. Please sign in with the method you originally used.",
  },
  OAuthSignin: {
    heading: "OAuth sign-in failed",
    message:
      "There was a problem signing in with your provider. Please try again.",
  },
  OAuthCallback: {
    heading: "OAuth callback error",
    message:
      "Something went wrong during the sign-in callback. Please try again.",
  },
  CredentialsSignin: {
    heading: "Invalid credentials",
    message: "The email or password you entered is incorrect.",
  },
  Default: {
    heading: "Something went wrong",
    message:
      "An unexpected error occurred during authentication. Please try again.",
  },
}

interface AuthErrorPageProps {
  searchParams: { error?: string }
}

export default function AuthErrorPage({ searchParams }: AuthErrorPageProps) {
  const errorCode = searchParams.error ?? "Default"
  const { heading, message } =
    ERROR_MESSAGES[errorCode] ?? ERROR_MESSAGES.Default

  return (
    <AuthCard
      title={heading}
      footer={
        <Link
          href="/login"
          className="font-medium text-neutral-900 underline-offset-2 hover:underline dark:text-neutral-50"
        >
          Back to sign in
        </Link>
      }
    >
      {/* Error icon */}
      <div className="mb-5 flex items-start gap-3 rounded-md bg-red-50 px-4 py-3 dark:bg-red-950/40">
        <svg
          xmlns="http://www.w3.org/2000/svg"
          viewBox="0 0 20 20"
          fill="currentColor"
          className="mt-0.5 h-5 w-5 shrink-0 text-red-400"
          aria-hidden="true"
        >
          <path
            fillRule="evenodd"
            d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.28 7.22a.75.75 0 00-1.06 1.06L8.94 10l-1.72 1.72a.75.75 0 101.06 1.06L10 11.06l1.72 1.72a.75.75 0 101.06-1.06L11.06 10l1.72-1.72a.75.75 0 00-1.06-1.06L10 8.94 8.28 7.22z"
            clipRule="evenodd"
          />
        </svg>
        <p className="text-sm text-red-700 dark:text-red-400">{message}</p>
      </div>

      {/* Error code — useful for support */}
      {errorCode !== "Default" && (
        <p className="text-center text-xs text-neutral-400">
          Error code:{" "}
          <code className="font-mono">{errorCode}</code>
        </p>
      )}
    </AuthCard>
  )
}
