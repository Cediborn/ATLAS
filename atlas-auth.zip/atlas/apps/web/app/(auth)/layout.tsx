import type { Metadata } from "next"

export const metadata: Metadata = {
  title: {
    template: "%s — Atlas",
    default: "Atlas",
  },
}

/**
 * Shared layout for all auth pages (/login, /register, /auth/error).
 * Centers the card both horizontally and vertically.
 * No sidebar, no header — auth pages are standalone.
 */
export default function AuthLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <div className="flex min-h-screen flex-col items-center justify-center bg-neutral-50 px-4 dark:bg-neutral-950">
      {children}
    </div>
  )
}
