import { handlers } from "@/auth"

// Auth.js v5 — export GET and POST from the handlers object
export const { GET, POST } = handlers
