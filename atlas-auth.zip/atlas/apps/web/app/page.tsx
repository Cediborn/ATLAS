import { redirect } from "next/navigation"
import { auth } from "@/auth"

/**
 * Root route — immediately redirects based on auth state.
 * "/" is never rendered as a visible page.
 */
export default async function RootPage() {
  const session = await auth()

  if (session?.user) {
    redirect("/dashboard")
  } else {
    redirect("/login")
  }
}
