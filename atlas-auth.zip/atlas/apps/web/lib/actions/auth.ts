"use server"

import { AuthError } from "next-auth"
import { signIn } from "@/auth"
import { db, users } from "@atlas/db"
import { eq } from "drizzle-orm"
import bcrypt from "bcryptjs"
import { loginSchema, registerSchema } from "@/lib/validators/auth"

// ---------------------------------------------------------------------------
// Shared state shape returned by both actions
// ---------------------------------------------------------------------------
export type AuthActionState = {
  error?: string
  fieldErrors?: Record<string, string>
} | null

// ---------------------------------------------------------------------------
// loginAction
// Called by <LoginForm> via useFormState. On success, Auth.js throws a
// NEXT_REDIRECT — we re-throw anything that's not an AuthError so Next.js
// can process the redirect correctly.
// ---------------------------------------------------------------------------
export async function loginAction(
  _prevState: AuthActionState,
  formData: FormData
): Promise<AuthActionState> {
  const raw = {
    email: formData.get("email"),
    password: formData.get("password"),
  }

  const parsed = loginSchema.safeParse(raw)
  if (!parsed.success) {
    const fieldErrors: Record<string, string> = {}
    for (const issue of parsed.error.issues) {
      const field = issue.path[0] as string
      fieldErrors[field] = issue.message
    }
    return { fieldErrors }
  }

  try {
    await signIn("credentials", {
      email: parsed.data.email,
      password: parsed.data.password,
      redirectTo: "/dashboard",
    })
  } catch (error) {
    // Re-throw NEXT_REDIRECT — this is how Auth.js + Next.js signal a redirect
    if (error instanceof Error && error.message === "NEXT_REDIRECT") throw error

    if (error instanceof AuthError) {
      switch (error.type) {
        case "CredentialsSignin":
          return { error: "Invalid email or password. Please try again." }
        case "AccessDenied":
          return { error: "Access denied. Please contact support." }
        default:
          return { error: "Unable to sign in. Please try again." }
      }
    }

    console.error("[loginAction]", error)
    return { error: "An unexpected error occurred. Please try again." }
  }

  return null
}

// ---------------------------------------------------------------------------
// registerAction
// Validates input, checks for duplicate email, hashes password, creates user,
// then immediately signs them in (redirects to /dashboard on success).
// ---------------------------------------------------------------------------
export async function registerAction(
  _prevState: AuthActionState,
  formData: FormData
): Promise<AuthActionState> {
  const raw = {
    name: formData.get("name"),
    email: formData.get("email"),
    password: formData.get("password"),
    confirmPassword: formData.get("confirmPassword"),
  }

  const parsed = registerSchema.safeParse(raw)
  if (!parsed.success) {
    const fieldErrors: Record<string, string> = {}
    for (const issue of parsed.error.issues) {
      const field = issue.path[0] as string
      if (!fieldErrors[field]) fieldErrors[field] = issue.message
    }
    return { fieldErrors }
  }

  const { name, email, password } = parsed.data

  try {
    // Reject duplicate emails before doing any work
    const existing = await db
      .select({ id: users.id })
      .from(users)
      .where(eq(users.email, email))
      .limit(1)

    if (existing.length > 0) {
      return {
        fieldErrors: { email: "An account with this email already exists." },
      }
    }

    // bcrypt work factor 12 — good balance of security and server latency
    const passwordHash = await bcrypt.hash(password, 12)

    await db.insert(users).values({ name, email, passwordHash })

    // Auto sign-in immediately after registration
    await signIn("credentials", {
      email,
      password,
      redirectTo: "/dashboard",
    })
  } catch (error) {
    if (error instanceof Error && error.message === "NEXT_REDIRECT") throw error

    if (error instanceof AuthError) {
      return {
        error:
          "Account created but sign-in failed. Please go to login and try again.",
      }
    }

    console.error("[registerAction]", error)
    return { error: "Failed to create account. Please try again." }
  }

  return null
}
