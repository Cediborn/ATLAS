import { type ClassValue, clsx } from "clsx"
import { twMerge } from "tailwind-merge"

/**
 * Merge Tailwind classes safely. Resolves conflicts (e.g. p-2 + p-4 → p-4)
 * and removes falsy values. Use everywhere class names are conditionally applied.
 */
export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}
