import { auth } from "@/auth"
import { redirect } from "next/navigation"
import type { AuthUser } from "./types"

// ---------------------------------------------------------------------------
// getCurrentUser
// Returns the authenticated user or null. Safe to call in any Server Component.
// Never throws — callers decide what to do when there's no session.
// ---------------------------------------------------------------------------
export async function getCurrentUser(): Promise<AuthUser | null> {
  const session = await auth()

  if (!session?.user?.id) return null

  return {
    id: session.user.id,
    name: session.user.name ?? null,
    email: session.user.email as string,
    image: session.user.image ?? null,
  }
}

// ---------------------------------------------------------------------------
// requireAuth
// Returns the authenticated user or redirects to /login.
// Use in protected layouts and server actions that must have a user.
// ---------------------------------------------------------------------------
export async function requireAuth(): Promise<AuthUser> {
  const user = await getCurrentUser()

  if (!user) {
    redirect("/login")
  }

  return user
}
