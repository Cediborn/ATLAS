import type { DefaultSession } from "next-auth"

// ---------------------------------------------------------------------------
// Augment NextAuth types so session.user.id is available everywhere
// without casting. Add more fields here as Atlas grows (role, workspaceId).
// ---------------------------------------------------------------------------
declare module "next-auth" {
  interface Session {
    user: {
      id: string
    } & DefaultSession["user"]
  }
}

declare module "next-auth/jwt" {
  interface JWT {
    id?: string
  }
}

// ---------------------------------------------------------------------------
// Convenience alias used across the app
// ---------------------------------------------------------------------------
export type AuthUser = {
  id: string
  name: string | null
  email: string
  image: string | null
}
