import NextAuth from "next-auth"
import type { NextAuthConfig, DefaultSession } from "next-auth"
import Google from "next-auth/providers/google"
import Credentials from "next-auth/providers/credentials"
import { DrizzleAdapter } from "@auth/drizzle-adapter"
import { eq } from "drizzle-orm"
import bcrypt from "bcryptjs"
import { db, users, accounts, sessions, verificationTokens } from "@atlas/db"
import { loginSchema } from "@/lib/validators/auth"

// ---------------------------------------------------------------------------
// Module augmentation — extends session.user with id field
// ---------------------------------------------------------------------------
declare module "next-auth" {
  interface Session {
    user: { id: string } & DefaultSession["user"]
  }
}

declare module "next-auth/jwt" {
  interface JWT { id?: string }
}

// ---------------------------------------------------------------------------
// Config
// ---------------------------------------------------------------------------
export const authConfig: NextAuthConfig = {
  trustHost: true,

  adapter: DrizzleAdapter(db, {
    usersTable: users,
    accountsTable: accounts,
    sessionsTable: sessions,
    verificationTokensTable: verificationTokens,
  }),

  session: { strategy: "jwt" },

  pages: {
    signIn: "/login",
    error: "/auth/error",
    newUser: "/dashboard",
  },

  providers: [
    Google,

    Credentials({
      name: "credentials",
      credentials: {
        email:    { label: "Email",    type: "email"    },
        password: { label: "Password", type: "password" },
      },
      async authorize(credentials) {
        const parsed = loginSchema.safeParse(credentials)
        if (!parsed.success) return null

        const { email, password } = parsed.data

        const user = await db
          .select()
          .from(users)
          .where(eq(users.email, email))
          .limit(1)
          .then((r) => r[0] ?? null)

        if (!user?.passwordHash) return null

        const ok = await bcrypt.compare(password, user.passwordHash)
        if (!ok) return null

        return { id: user.id, name: user.name, email: user.email, image: user.image }
      },
    }),
  ],

  callbacks: {
    jwt({ token, user }) {
      if (user?.id) token.id = user.id
      return token
    },
    session({ session, token }) {
      if (token.id) session.user.id = token.id as string
      return session
    },
  },
}

export const { handlers, auth, signIn, signOut } = NextAuth(authConfig)
