import type { NextConfig } from "next"

const nextConfig: NextConfig = {
  // Strict mode catches React lifecycle bugs early
  reactStrictMode: true,

  // Required for @neondatabase/serverless in serverless environments
  serverExternalPackages: ["@neondatabase/serverless"],

  // Monorepo: allow imports from packages/*
  transpilePackages: ["@atlas/db"],
}

export default nextConfig
