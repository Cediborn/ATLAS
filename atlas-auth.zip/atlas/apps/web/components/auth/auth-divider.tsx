/**
 * Visual separator between the credentials form and OAuth buttons.
 * Purely presentational — no client JS needed.
 */
export function AuthDivider() {
  return (
    <div className="relative my-5" aria-hidden="true">
      <div className="absolute inset-0 flex items-center">
        <span className="w-full border-t border-neutral-200 dark:border-neutral-800" />
      </div>
      <div className="relative flex justify-center">
        <span className="bg-white px-3 text-xs text-neutral-400 dark:bg-neutral-900 dark:text-neutral-500">
          or continue with
        </span>
      </div>
    </div>
  )
}
