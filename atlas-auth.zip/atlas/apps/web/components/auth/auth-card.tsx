import { cn } from "@/lib/utils"

interface AuthCardProps {
  title: string
  description?: string
  children: React.ReactNode
  footer?: React.ReactNode
  className?: string
}

/**
 * Outer container used on all auth pages.
 * Follows Atlas design system: 12px card radius, 1px border elevation.
 */
export function AuthCard({
  title,
  description,
  children,
  footer,
  className,
}: AuthCardProps) {
  return (
    <div
      className={cn(
        "w-full max-w-[400px]",
        "rounded-lg border border-neutral-200 bg-white",
        "px-8 pb-8 pt-7 shadow-sm",
        "dark:border-neutral-800 dark:bg-neutral-900",
        className
      )}
    >
      {/* Wordmark */}
      <div className="mb-6 flex items-center gap-2">
        <span className="text-[15px] font-semibold tracking-tight text-neutral-900 dark:text-neutral-50">
          Atlas
        </span>
      </div>

      {/* Heading */}
      <div className="mb-6 space-y-1">
        <h1 className="text-xl font-semibold tracking-tight text-neutral-900 dark:text-neutral-50">
          {title}
        </h1>
        {description && (
          <p className="text-sm text-neutral-500 dark:text-neutral-400">
            {description}
          </p>
        )}
      </div>

      {/* Form / content */}
      {children}

      {/* Footer link (e.g. "Don't have an account?") */}
      {footer && (
        <div className="mt-6 text-center text-sm text-neutral-500 dark:text-neutral-400">
          {footer}
        </div>
      )}
    </div>
  )
}
