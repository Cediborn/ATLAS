import NextAuth from "next-auth"
import type { NextAuthConfig } from "next-auth"
import Google from "next-auth/providers/google"
import Credentials from "next-auth/providers/credentials"
import { DrizzleAdapter } from "@auth/drizzle-adapter"
import { eq } from "drizzle-orm"
import bcrypt from "bcryptjs"
import { db, users, accounts, sessions, verificationTokens } from "@atlas/db"
import { loginSchema } from "@/lib/validators/auth"

// Ensure type augmentations are applied
import "@/lib/auth/types"

// ---------------------------------------------------------------------------
// Auth.js v5 configuration
// Strategy: JWT — compatible with both Credentials and OAuth in the same app.
// Adapter: DrizzleAdapter — persists users + accounts; sessions stay in JWT.
// ---------------------------------------------------------------------------
export const authConfig: NextAuthConfig = {
  // Required in production. Set AUTH_SECRET in your env.
  trustHost: true,

  adapter: DrizzleAdapter(db, {
    // Map Auth.js to our plural, snake_case Atlas table names
    usersTable: users,
    accountsTable: accounts,
    sessionsTable: sessions,
    verificationTokensTable: verificationTokens,
  }),

  // JWT: one strategy for both Credentials and OAuth — simpler and consistent
  session: { strategy: "jwt" },

  pages: {
    signIn: "/login",
    error: "/auth/error",
    newUser: "/dashboard", // Post-OAuth registration redirect
  },

  providers: [
    // ------------------------------------------------------------------
    // Google OAuth
    // Auto-reads AUTH_GOOGLE_ID and AUTH_GOOGLE_SECRET from environment.
    // ------------------------------------------------------------------
    Google,

    // ------------------------------------------------------------------
    // Email + Password credentials
    // Runs server-side only (Node.js runtime) — bcrypt is safe here.
    // ------------------------------------------------------------------
    Credentials({
      name: "credentials",
      credentials: {
        email: { label: "Email", type: "email" },
        password: { label: "Password", type: "password" },
      },
      async authorize(credentials) {
        const parsed = loginSchema.safeParse(credentials)
        if (!parsed.success) return null

        const { email, password } = parsed.data

        const user = await db
          .select()
          .from(users)
          .where(eq(users.email, email))
          .limit(1)
          .then((rows) => rows[0] ?? null)

        // No user found or OAuth-only account (no password set)
        if (!user?.passwordHash) return null

        const passwordMatch = await bcrypt.compare(password, user.passwordHash)
        if (!passwordMatch) return null

        return {
          id: user.id,
          name: user.name,
          email: user.email,
          image: user.image,
        }
      },
    }),
  ],

  callbacks: {
    // Persist user.id into the JWT on first sign-in
    jwt({ token, user }) {
      if (user?.id) {
        token.id = user.id
      }
      return token
    },

    // Expose user.id on the session so server components can read it directly
    session({ session, token }) {
      if (token.id) {
        session.user.id = token.id as string
      }
      return session
    },
  },
}

export const { handlers, auth, signIn, signOut } = NextAuth(authConfig)
