"use client"

import { useFormState, useFormStatus } from "react-dom"
import Link from "next/link"
import { loginAction, type AuthActionState } from "@/lib/actions/auth"
import { cn } from "@/lib/utils"

// ---------------------------------------------------------------------------
// SubmitButton — separate component so useFormStatus can reach the form above it
// ---------------------------------------------------------------------------
function SubmitButton() {
  const { pending } = useFormStatus()

  return (
    <button
      type="submit"
      disabled={pending}
      aria-disabled={pending}
      className={cn(
        "flex w-full items-center justify-center rounded-md",
        "bg-neutral-900 px-4 py-2.5 text-sm font-medium text-white",
        "transition-colors duration-[120ms]",
        "hover:bg-neutral-800 active:bg-neutral-950",
        "focus-visible:outline focus-visible:outline-2",
        "focus-visible:outline-offset-2 focus-visible:outline-neutral-900",
        "disabled:cursor-not-allowed disabled:opacity-50",
        "dark:bg-neutral-50 dark:text-neutral-900",
        "dark:hover:bg-neutral-200"
      )}
    >
      {pending ? (
        <>
          <svg
            className="-ml-0.5 mr-2 h-4 w-4 animate-spin"
            xmlns="http://www.w3.org/2000/svg"
            fill="none"
            viewBox="0 0 24 24"
            aria-hidden="true"
          >
            <circle
              className="opacity-25"
              cx="12"
              cy="12"
              r="10"
              stroke="currentColor"
              strokeWidth="4"
            />
            <path
              className="opacity-75"
              fill="currentColor"
              d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z"
            />
          </svg>
          Signing in…
        </>
      ) : (
        "Sign in"
      )}
    </button>
  )
}

// ---------------------------------------------------------------------------
// Shared input styles — keeps the form DRY without a full design-system import
// ---------------------------------------------------------------------------
const inputClass = cn(
  "w-full rounded-md border border-neutral-200 bg-white",
  "px-3 py-2.5 text-sm text-neutral-900 placeholder:text-neutral-400",
  "transition-colors duration-[120ms]",
  "focus:border-neutral-900 focus:outline-none focus:ring-2 focus:ring-neutral-900/10",
  "dark:border-neutral-700 dark:bg-neutral-800/50 dark:text-neutral-50",
  "dark:placeholder:text-neutral-500",
  "dark:focus:border-neutral-400 dark:focus:ring-neutral-400/10"
)

const errorInputClass = cn(
  "border-red-400 focus:border-red-500 focus:ring-red-500/10",
  "dark:border-red-500 dark:focus:border-red-400"
)

const labelClass =
  "block text-sm font-medium text-neutral-700 dark:text-neutral-300"

const fieldErrorClass = "mt-1 text-xs text-red-500 dark:text-red-400"

// ---------------------------------------------------------------------------
// LoginForm
// ---------------------------------------------------------------------------
export function LoginForm() {
  const [state, action] = useFormState<AuthActionState, FormData>(
    loginAction,
    null
  )

  const fieldErrors = state?.fieldErrors ?? {}

  return (
    <form action={action} noValidate className="space-y-4">
      {/* Global error banner */}
      {state?.error && (
        <div
          role="alert"
          className="rounded-md bg-red-50 px-4 py-3 text-sm text-red-600 dark:bg-red-950/40 dark:text-red-400"
        >
          {state.error}
        </div>
      )}

      {/* Email */}
      <div>
        <label htmlFor="email" className={labelClass}>
          Email
        </label>
        <input
          id="email"
          name="email"
          type="email"
          autoComplete="email"
          required
          className={cn(inputClass, fieldErrors.email && errorInputClass, "mt-1.5")}
          placeholder="you@example.com"
          aria-describedby={fieldErrors.email ? "email-error" : undefined}
          aria-invalid={!!fieldErrors.email}
        />
        {fieldErrors.email && (
          <p id="email-error" className={fieldErrorClass}>
            {fieldErrors.email}
          </p>
        )}
      </div>

      {/* Password */}
      <div>
        <div className="flex items-center justify-between">
          <label htmlFor="password" className={labelClass}>
            Password
          </label>
          <Link
            href="/forgot-password"
            className="text-xs text-neutral-500 underline-offset-2 hover:underline dark:text-neutral-400"
            tabIndex={0}
          >
            Forgot password?
          </Link>
        </div>
        <input
          id="password"
          name="password"
          type="password"
          autoComplete="current-password"
          required
          className={cn(
            inputClass,
            fieldErrors.password && errorInputClass,
            "mt-1.5"
          )}
          placeholder="••••••••"
          aria-describedby={fieldErrors.password ? "password-error" : undefined}
          aria-invalid={!!fieldErrors.password}
        />
        {fieldErrors.password && (
          <p id="password-error" className={fieldErrorClass}>
            {fieldErrors.password}
          </p>
        )}
      </div>

      <SubmitButton />
    </form>
  )
}
