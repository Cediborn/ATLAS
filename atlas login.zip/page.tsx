import type { Metadata } from "next"
import Link from "next/link"
import { AuthCard } from "@/components/auth/auth-card"
import { LoginForm } from "@/components/auth/login-form"
import { AuthDivider } from "@/components/auth/auth-divider"
import { GoogleButton } from "@/components/auth/google-button"

export const metadata: Metadata = {
  title: "Sign in",
  description: "Sign in to your Atlas account.",
}

export default function LoginPage() {
  return (
    <AuthCard
      title="Welcome back"
      description="Sign in to continue to Atlas."
      footer={
        <>
          Don&apos;t have an account?{" "}
          <Link
            href="/register"
            className="font-medium text-neutral-900 underline-offset-2 hover:underline dark:text-neutral-50"
          >
            Create one
          </Link>
        </>
      }
    >
      <LoginForm />
      <AuthDivider />
      <GoogleButton callbackUrl="/dashboard" />
    </AuthCard>
  )
}
